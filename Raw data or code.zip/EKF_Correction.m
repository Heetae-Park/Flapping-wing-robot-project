function [xhatp,K,Pp] = EKF_Correction(xhat_,P_,z,R,H,dt)
Rs = R/dt;

% Equation 3: Residual
nu = z - H*xhat_;

% Equation 4: Innovation covariance
S = H*P_*H' + Rs;

% Equation 5: Kalman gain
K = P_*H'*S^-1;

% Equation 6: State update
xhatp = xhat_ + K*nu;

% Equation 7: Covariance update
Pp = (eye(size(K*H)) - K*H)*P_;
Pp = (Pp + Pp') / 2;
