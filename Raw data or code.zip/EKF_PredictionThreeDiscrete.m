function [xhat_,P_] = EKF_PredictionThreeDiscrete(xhatp,rates,Pp,dt,Q)
% =========================================================================
% Help function
r2d = 180/pi;
d2r = pi/180;

% =========================================================================
% State variable x = [phi; theta; psi]
phi = xhatp(1); theta = xhatp(2); psi = xhatp(3);

% Internal variables
sinPhi = sin(phi); cosPhi = cos(phi); tanPhi = tan(phi);
sinTheta = sin(theta); cosTheta = cos(theta); tanTheta = tan(theta); secTheta = sec(theta);

% Gyroscope data
p = rates(1); q = rates(2); r = rates(3);

% =========================================================================
% Jacobian matrix
A = zeros(3,3);
A(1,1) = q*cosPhi*tanTheta - r*sinPhi*tanTheta;
A(1,2) = q*sinPhi*(secTheta)^2 + r*cosPhi*(secTheta)^2;
A(1,3) = 0;

A(2,1) = -q*sinPhi - r*cosPhi;
A(2,2) = 0;
A(2,3) = 0;

A(3,1) = q*cosPhi*secTheta - r*sinPhi*secTheta;
A(3,2) = q*sinPhi*secTheta*tanTheta + r*cosPhi*secTheta*tanTheta;
A(3,3) = 0;

% Process noise matrix
Gamma =...
    [1, sinPhi*tanTheta, cosPhi*tanTheta;...
     0, cosPhi, -sinPhi;...
     0, sinPhi/cosTheta, cosPhi/cosTheta];

% =========================================================================
% Discretization : This makes the system model: x_k+1 = As*x_k + Bs*u_k +
% w_k
As = eye(3) + A*dt + A^2*dt^2/2;
Qs = Gamma*Q*Gamma'*dt + (A*Gamma*Q*Gamma' + Gamma*Q*Gamma'*A')*dt^2/2;

% Estimate
xhat_dot = [p + q*sinPhi*tanTheta + r*cosPhi*tanTheta; ...
            q*cosPhi - r*sinPhi; ...
            q*sinPhi*secTheta + r*cosPhi*secTheta];

xhat_ = xhatp + xhat_dot*dt;

% Error covariance
P_ = As*Pp*As' + Qs;
