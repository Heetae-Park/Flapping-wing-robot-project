clearvars; close all; clc

d2r = pi/180;
r2d = 180/pi;

%% Data
A = xlsread('attitude_estimation_experiment2_onboard_data');
A = A(1375:1375+16581,:);

T = (A(:,1) - A(1,1))/1000000;
dt = 1/200; fs = 1/dt;

phi_deg = A(:,2);
theta_deg = A(:,3);
psi_deg = A(:,4);

gx = A(:,5);
gy = A(:,6);
gz = A(:,7);

ax = A(:,8);
ay = A(:,9);
az = A(:,10);

mx = A(:,11);
my = A(:,12);
mz = A(:,13);

phi_cmd = A(:,14);
theta_cmd = A(:,15);

p_cmd = A(:,17);
q_cmd = A(:,18);

rservo = A(:,19);
pservo = A(:,20);
yservo = A(:,21);

fc0 = 18;
[b0,a0] = butter(1,fc0/(fs/2));

fc = 20;
[b1,a1] = butter(1,1*[fc-1.5*3 fc+1.5*3]/(fs/2),'stop');
[b2,a2] = butter(1,2*[fc-1.5*3 fc+1.5*3]/(fs/2),'stop');
[b3,a3] = butter(1,3*[fc-1.5*3 fc+1.5*3]/(fs/2),'stop');
[b4,a4] = butter(1,4*[fc-1.5*3 fc+1.5*3]/(fs/2),'stop');
b_bsf = conv(conv(conv(conv(b0,b1),b2),b3),b4);
a_bsf = conv(conv(conv(conv(a0,a1),a2),a3),a4);

gx_bsf = filter(b_bsf,a_bsf,gx); gy_bsf = filter(b_bsf,a_bsf,gy); gz_bsf = filter(b_bsf,a_bsf,gz);
ax_bsf = filter(b_bsf,a_bsf,ax); ay_bsf = filter(b_bsf,a_bsf,ay); az_bsf = filter(b_bsf,a_bsf,az);

%% Motion capture data
B = xlsread('attitude_estimation_experiment2_reference_data');

T_mo = B(688:10628,2);
T_mo = T_mo - T_mo(1);

x = B(688:10628,5);
y = -B(688:10628,3);
z = -B(688:10628,4);
w = B(688:10628,6);

[psi_t,theta_t,phi_t] = quat2angle([w x y z],'ZYX');
[b,a] = butter(4,10/(fs/2));
phi_t_lpf = filtfilt(b,a,phi_t); theta_t_lpf = filtfilt(b,a,theta_t); 

diffPsi_t = diff(psi_t);
psi_nt = zeros(size(psi_t)); psi_nt(1) = psi_t(1);
for i = 1:length(diffPsi_t)
    if diffPsi_t(i) <= -pi
        diffPsi_t(i) = diffPsi_t(i) + 2*pi;
    elseif diffPsi_t(i) >= pi
        diffPsi_t(i) = diffPsi_t(i) - 2*pi;
    end
    psi_nt(i+1) = psi_nt(i) + diffPsi_t(i);
end
psi_nt_lpf = filtfilt(b,a,psi_nt); 

phi_dot = [0; diff(phi_t_lpf)/(1/120)]; theta_dot = [0; diff(theta_t_lpf)/(1/120)]; psi_dot = [0; diff(psi_nt_lpf)/(1/120)];

% Reference body rate
p_ref = zeros(length(T_mo),1); q_ref = zeros(length(T_mo),1); r_ref = zeros(length(T_mo),1);
for i = 1:length(T_mo)-1
    sinPhi = sin(phi_t_lpf(i)); cosPhi = cos(phi_t_lpf(i)); tanPhi = tan(phi_t_lpf(i));
    sinTheta = sin(theta_t_lpf(i)); cosTheta = cos(theta_t_lpf(i)); tanTheta = tan(theta_t_lpf(i));
    
    p_ref(i) = phi_dot(i+1) - sinTheta*psi_dot(i+1);
    q_ref(i) = cosPhi*theta_dot(i) + cosTheta*sinPhi*psi_dot(i+1);
    r_ref(i) = -sinPhi*theta_dot(i+1) + cosTheta*cosPhi*psi_dot(i+1) ;
end

figure; 
subplot(3,1,1); pp = plot(T_mo,p_ref*r2d,T,filtfilt(b_bsf,a_bsf,gx)); grid on; xlim([20 45]); ylim([-100 100]); legend('Reference','Sensor');
xlabel('Time  (sec)'); ylabel('Roll rate  (\circ/s)'); set(gca,'FontSize',18);
subplot(3,1,2); pp = plot(T_mo,q_ref*r2d,T,filtfilt(b_bsf,a_bsf,gy)); grid on; xlim([20 45]); ylim([-100 100]);
xlabel('Time  (sec)'); ylabel('Pitch rate  (\circ/s)'); set(gca,'FontSize',18);
subplot(3,1,3); pp = plot(T_mo,r_ref*r2d,T,filtfilt(b_bsf,a_bsf,gz)); grid on; xlim([20 45]); ylim([-100 100]);
xlabel('Time  (sec)'); ylabel('Yaw rate  (\circ/s)'); set(gca,'FontSize',18);


%% Fourier
% FFT 
nfft = length(T); % Length of FFT
a = gz;
X = fft(a,nfft); % Take fft, padding with zeros so that length(X) is equal to nfft 

% Power in Frequency % FFT is symmetric, throw away second half 
P2 = abs(X/nfft);
P1 = P2(1:nfft/2+1);
P1(2:end-1) = 2*P1(2:end-1);

% Frequency vector
f = fs*(0:(nfft/2))/nfft;

% Generate the plot, title and labels. 
figure; plot(f,P1); grid on; axis square; 
title('Single-Sided Amplitude Spectrum of a_x(t)'); xlabel('Frequency [Hz]'); ylabel('|a_x(f)|');


[p,fd,td] = pspectrum(a,fs,'spectrogram','FrequencyLimits',[5 30],'MinThreshold',0,'TimeResolution',1);
[psf,pst] = instfreq(p,fd,td);
figure;
subplot(2,1,1); instfreq(p,fd,td);
subplot(2,1,2); plot(pst,psf)

%% EKF
% Initialization of the sizes of vectors and matrices
Nsamples = length(gx);

% number of state
nx = 3; 
% nx = 6; 

% number of measurements
nm = 2; 

% Measurement matrix
H = zeros(nm,nx); H(1,1) = 1; H(2,2) = 1;

% State variables
xhatp = zeros(nx,length(T));

% Covariance
sigma_P_ = zeros(nx,length(T));
sigma_Pp = zeros(nx,length(T));

% Initial Conditions
% Guess of initial posterior value
xhatp(:,1) = [atan2(-ay(1),-az(1)); atan2(ax(1),sqrt(ay(1)^2 + az(1)^2)); 0];
% xhatp(:,1) = [atan2(-ay(1),-az(1)); atan2(ax(1),sqrt(ay(1)^2 + az(1)^2)); 0; 0; 0; 0];

% Guess of initial error covariance
Pp = 1e1*eye(nx); sigma_Pp(:,1) = sqrt(diag(Pp));

% Kalman gain
K_store = zeros(1,length(T));

K_traj11 = zeros(1,length(T));
K_traj12 = zeros(1,length(T));
K_traj21 = zeros(1,length(T));
K_traj22 = zeros(1,length(T));
K_traj31 = zeros(1,length(T));
K_traj32 = zeros(1,length(T));

% Noise
sigma_w = [0.5 0.5 0.5]*pi/180; % system noise
sigma_v = [5 5]*pi/180; % measurement noise
Q = diag(sigma_w.^2);
R = diag(sigma_v.^2);

% Sensor data
p = gx_bsf*d2r; q = gy_bsf*d2r; r = gz_bsf*d2r;
phi_a = atan2(-ay_bsf,-az_bsf); theta_a = atan2(ax_bsf,sqrt(ay_bsf.^2+az_bsf.^2));

for i = 1:length(T)-1
    %------------------------------------------------------------------
    % Time update (Every step)
    %------------------------------------------------------------------
    rates = [p(i) q(i) r(i)]';
    [xhat_,P_] = EKF_PredictionThreeDiscrete(xhatp(:,i),rates,Pp,dt,Q);
%     [xhat_,P_] = EKF_PredictionSixDiscrete(xhatp(:,i),rates,Pp,dt,Q);
    sigma_P_(:,i+1) = sqrt(diag(P_));
    
    %------------------------------------------------------------------
    % Measurement update
    %------------------------------------------------------------------
    % Measurement generation
    phi_m   = atan2(-ay_bsf(i), -az_bsf(i) );
    theta_m = atan2( ax_bsf(i), sqrt(ay_bsf(i)^2 + az_bsf(i)^2) );
    z = [phi_m; theta_m]; % [rad]
    
    % Correction
    [xhatp(:,i+1),K,Pp] = EKF_Correction(xhat_,P_,z,R,H,dt);
    % Storing error covariance for ploting
    sigma_Pp(:,i+1) = sqrt(diag(Pp));
    % Storing Kalman gain for ploting
    K_store(i) = norm(K);
    K_traj11(i) = K(1,1); K_traj12(i) = K(1,2);
    K_traj21(i) = K(2,1); K_traj22(i) = K(2,2);
    K_traj31(i) = K(3,1); K_traj32(i) = K(3,2);
end

% Covariance plot
figure;
subplot(311); pp = plot(T(2:end),sigma_P_(1,2:end).^2,'o',T(2:end),sigma_Pp(1,2:end).^2,'^');  xlim([0 0.1]);
legend('Priori','Posteriori'); xlabel('Time  (sec)'); ylabel('Error covariance of \it{x_{1}}');
set(pp(:),'MarkerSize',6); set(pp(1),'MarkerFaceColor',pp(1).Color); set(pp(2),'MarkerFaceColor',pp(2).Color);

subplot(312); pp = plot(T(2:end),sigma_P_(2,2:end).^2,'o',T(2:end),sigma_Pp(2,2:end).^2,'^'); xlim([0 0.1]);
legend('Priori','Posteriori'); xlabel('Time  (sec)'); ylabel('Error covariance of \it{x_{2}}');
set(pp(:),'MarkerSize',6); set(pp(1),'MarkerFaceColor',pp(1).Color); set(pp(2),'MarkerFaceColor',pp(2).Color);

% subplot(313); pp = plot(T(2:end),sigma_P_(3,2:end).^2,'o',T(2:end),sigma_Pp(3,2:end).^2,'^'); xlim([0 0.1]);
% legend('Priori','Posteriori'); xlabel('Time [sec]'); ylabel('Error covariance of x_{3}'); 
% set(pp(:),'MarkerSize',6); set(pp(1),'MarkerFaceColor',pp(1).Color); set(pp(2),'MarkerFaceColor',pp(2).Color);
subplot(313); pp = plot(T,K_store); xlim([0 0.1]);
set(pp,'LineWidth',1); xlabel('Time  (sec)'); ylabel('Kalman gain norm');

% Kalman gain plot
% figure; pp = plot(T,K_store); xlim([0 0.1]);
% set(pp,'LineWidth',1); xlabel('Time [sec]'); ylabel('|K|');
% figure; pp = plot(T,K_traj11,T,K_traj12,T,K_traj21,T,K_traj22,T,K_traj31,T,K_traj32); set(pp(:),'LineWidth',1); xlim([0 0.1]);
% xlabel('Time [sec]'); ylabel('Kalman gain element'); legend('K_{11}','K_{12}','K_{21}','K_{22}','K_{31}','K_{32}');

%% Complementary filter
xhatp_cf = zeros(3,length(T));
xhatp_cf(:,1) = [phi_a(1); theta_a(1); 0];

bias_inertial = zeros(3,length(T));
bias_pqr = zeros(3,length(T));

gainset = [0.1 0.002];

for i = 1:length(T)-1
    rate = [p(i) q(i) r(i)]'; % in rad/s
    acc = [ax(i) ay(i) az(i)]';
    [xhatp_cf(:,i+1),bias_inertial(:,i+1),bias_pqr(:,i+1)] = CF(xhatp_cf(:,i),bias_inertial(:,i),rate,acc,gainset,dt);

end

figure; 
subplot(311); pp = plot(pst,psf); 
xlabel('Time  (sec)'); ylabel('Flapping freqeuncy  (Hz)'); xlim([0 90]); grid on;
set(pp,'LineWidth',1); set(gca,'FontSize',18);

subplot(312); pp = plot(T_mo,phi_t_lpf*r2d,'-',T,xhatp_cf(1,:)*r2d); legend('Reference','Complementary');
xlabel('Time  (sec)'); ylabel('Roll angle  (\circ)'); xlim([0 90]); ylim([-40 40]); grid on;
set(pp,'LineWidth',1); set(gca,'FontSize',18);

subplot(313); pp = plot(T_mo,theta_t_lpf*r2d,'-',T,xhatp_cf(2,:)*r2d); %legend('reference','kalman','complimentary');
xlabel('Time  (sec)'); ylabel('Pitch angle  (\circ)'); xlim([0 90]); ylim([-40 40]); grid on;
set(pp,'LineWidth',1); set(gca,'FontSize',18);

figure;
subplot(211); pp = plot(T,bias_inertial(1,:)*r2d,T,bias_pqr(1,:)*r2d);
xlabel('Time  (sec)'); ylabel('Rate bias in X frame  (\circ/sec)'); set(pp,'LineWidth',1); grid on; legend('Inertial','Body'); xlim([0 90]); ylim([-2 2]);
subplot(212); pp = plot(T,bias_inertial(2,:)*r2d,T,bias_pqr(2,:)*r2d);
xlabel('Time  (sec)'); ylabel('Rate bias in Y frame  (\circ/sec)'); set(pp,'LineWidth',1); grid on; legend('Inertial','Body'); xlim([0 90]); ylim([-2 2]);

% Interpolation
xq = linspace(T_mo(1),T_mo(end),numel(T));

vp = interp1(T_mo,phi_t_lpf,xq);
vp(end) = vp(end-1);

vt = interp1(T_mo,theta_t_lpf,xq);
vt(end) = vt(end-1);

RMSE_phi_KF = sqrt((vp*r2d - xhatp(1,:)*r2d)*(vp*r2d - xhatp(1,:)*r2d)'/ numel(vp));
RMSE_theta_KF = sqrt((vt*r2d - xhatp(2,:)*r2d)*(vt*r2d - xhatp(2,:)*r2d)'/ numel(vt));

RMSE_phi_CF = sqrt((vp*r2d - xhatp_cf(1,:)*r2d)*(vp*r2d - xhatp_cf(1,:)*r2d)'/ numel(vp))
RMSE_theta_CF = sqrt((vt*r2d - xhatp_cf(2,:)*r2d)*(vt*r2d - xhatp_cf(2,:)*r2d)'/ numel(vt))