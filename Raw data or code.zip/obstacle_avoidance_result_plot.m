close all;
M = csvread('obstacle_avoidance_result.csv',1,0);
Time = M(:,1)/1000; % msec -> sec
d_vel_az = M(:,2);  % yaw rate command
H = M(:,3);         % Entropy
% of_rl_e = M(:,4); % optical flow difference
of_rl_e_f = M(:,5); % optical flow difference with low pass filter

start_time = 51; % sec
end_time = 350; % sec
start_ind = find(Time>start_time,1);
end_ind = find(Time>end_time,1);
exp_time = start_ind:end_ind;

figure; hold on;
subplot(3,1,1);
plot(Time(exp_time)-start_time,of_rl_e_f(exp_time), 'm-','LineWidth', 2);
xlabel('time (sec)','FontSize', 12); 
ylabel({'Optical flow'; 'difference'},'FontSize', 12);
ylim([-500,500]);

subplot(3,1,2);
plot(Time(exp_time)-start_time, H(exp_time), 'b-', 'LineWidth',2); 
xlabel('time (sec)','FontSize', 12); 
ylabel('Entropy','FontSize', 12); 
ylim([1.0,3.0]);

subplot(3,1,3);
plot(Time(exp_time)-start_time, d_vel_az(exp_time),'r-', 'LineWidth', 2);
xlabel('time (sec)','FontSize', 12); 
ylabel('yaw rate cmd','FontSize', 12);
