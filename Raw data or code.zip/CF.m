function [xhatp,bias_inertial,bias_pqr] = CF(xhat_,bias_,rate,acc,gainset,dt)

phi = xhat_(1); theta = xhat_(2); psi = xhat_(3);
sinPhi = sin(phi); cosPhi = cos(phi); tanPhi = tan(phi);
sinTheta = sin(theta); cosTheta = cos(theta); tanTheta = tan(theta);

R = [1, sinPhi*tanTheta, cosPhi*tanTheta;...
    0, cosPhi, -sinPhi;...
    0, sinPhi/cosTheta, cosPhi/cosTheta];

p = rate(1); q = rate(2); r = rate(3);
ax = acc(1); ay = acc(2); az = acc(3);

kp = gainset(1); ki = gainset(2);

yu = R*rate;
yx = [atan2(-ay,-az); atan2(ax,sqrt(ay^2+az^2)); 0];

delta = yx - xhat_;
bias_inertialDot = -ki*(yx - xhat_);
bias_inertial = bias_ + bias_inertialDot*dt;

bias_pqr = R\bias_inertial;

xhatpDot = yu + kp*delta + bias_inertial;
xhatp = xhat_ + xhatpDot*dt;